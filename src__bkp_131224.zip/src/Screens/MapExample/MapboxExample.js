import React from 'react'

function MapboxExample() {
  // const [loaded, error] = useScript(
  //   "https://maps.googleapis.com/maps/api/js?key=AIzaSyA6vKL6Q4u5ZhGAJlYOMkQZ13pxCUXOe9k"
  // );
  return (
    <div>MapboxExample</div>
  )
}

export default MapboxExample



