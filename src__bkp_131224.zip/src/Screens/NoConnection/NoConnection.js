import React from 'react'
import FooterCus from '../../Components/FooterCus'

function NoConnection() {
  return (
    <>

    <div className='no_internateBaner'>


    </div>
    
    <div className="wrapper">
    <div className="inner_page_Sec">
   
    <div className="col-sm-12 left_sec no_internateText">

    <h1>No Internet</h1>

    <p>
    <span>Slow or no Internet connection</span>
    Check your connection or try again
    </p>

    

    </div>

    </div>
    </div>

    <FooterCus/>
  </>
  )
}

export default NoConnection