export default navigationRoutes = {
    receiptScreen: "ReceiptScreen",
    ReceiptScreen_Bletooth: "ReceiptScreen_Bletooth",
    outpassScreen: "OutpassScreen",
    reportScreen: "ReportScreen",
    settingsScreen: "SettingNavigation",
    printScreen: "PrintNavigation",
  
    login: "login",
    signup: "signup",
    forgotPassword: "forgotPassword",
    otpValidation: "otpValidation",
  };
  