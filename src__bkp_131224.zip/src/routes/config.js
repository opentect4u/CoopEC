// export const BASE_URL_V3 = "https://myparking.opentech4u.co.in/v3/api";
export const BASE_URL = "https://admincecwb.opentech4u.co.in";
// export const BASE_URL_V3 = "http://192.168.1.252:3001/v3/api";
